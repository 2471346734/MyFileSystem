#include "Head.h"

void CutFile(string FileName, string path)
{
	//CopyFile(FileName, path);
	//DeleteFile(FileName);
	cout << "�ļ����гɹ�" << endl;
}