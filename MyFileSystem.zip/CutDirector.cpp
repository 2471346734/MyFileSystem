#include "Head.h"

void CutDirector(string DirectorName, string path)
{
	//CopyDirector(DirectorName, path);
	//DeleteDirector(DirectorName);
	cout << "�ļ��м��гɹ�" << endl;
}